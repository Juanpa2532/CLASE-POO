package duts.duts_sebastian_mendoza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
        
public class Database {
    private static final String HOST = "sql10.freesqldatabase.com";
    private static final String DATABASE = "sql10748107";
    private static final String USER = "sql10748107";
    private static final String PASSWORD = "ShU4M5Z5yr";
    private static final String SSL = "false";
    
    private static String cedulaUsuario;
    private static String nombreUsuario;
    private static String correoUsuario;
    private static long dutsUsuario;
    private static long[] promedios = new long[4];
    
    private static final String URL = String.format("jdbc:mysql://%s:3306/%s?useSSL=%s&serverTimezone=UTC", HOST, DATABASE, SSL);
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    
    public static boolean login(String usuario, String clave) {
        String query = "SELECT * FROM usuarios WHERE correo = ? AND clave = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            // Parámetros de la consulta
            statement.setString(1, usuario);
            statement.setString(2, clave);

            // Ejecutar la consulta
            try (ResultSet resultSet = statement.executeQuery()) {
                // Procesar resultado
                if (resultSet.next()) {
                    cedulaUsuario = resultSet.getString("cedula");
                    nombreUsuario = resultSet.getString("nombre");
                    correoUsuario = resultSet.getString("correo");
                    dutsUsuario = resultSet.getLong("duts");
                    
                    promedioDuts(cedulaUsuario);
                    return true; // Usuario válido
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al realizar el login: " + e.getMessage());
        }

        return false; // Usuario no encontrado o error
    }
    
    public static boolean registrar(String cedula, String nombre, String correo, String clave){
        String query = "INSERT INTO usuarios (cedula, nombre, correo, clave, duts) VALUES (?, ?, ?, ?, 0);";
        
        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, cedula);
            statement.setString(2, nombre);
            statement.setString(3, correo);
            statement.setString(4, clave);

            int filasAfectadas = statement.executeUpdate();
            
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar usuario: " + e.getMessage());
        }

        return false; // Si ocurre un error
    }
    
    public static String enviarDuts(String cedula, long cantidad){
        
        if(cantidad > dutsUsuario){
            return "Su saldo en duts no alcanza para esta transacción";
        }
        
        String query = "UPDATE usuarios SET duts = duts + ? WHERE cedula = ?";
        
        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setLong(1, cantidad);
            statement.setString(2, cedula);

            int filasAfectadas = statement.executeUpdate();
            
            if(filasAfectadas > 0) {
                
                String queryRestarDuts = "UPDATE usuarios SET duts = duts - ? WHERE cedula = ?";
                
                try (PreparedStatement statementRestarDuts = connection.prepareStatement(queryRestarDuts)){
                    statementRestarDuts.setLong(1, cantidad);
                    statementRestarDuts.setString(2, cedulaUsuario);
                    
                    int filasAfectadasRestarDuts = statementRestarDuts.executeUpdate();
                    
                    if(filasAfectadasRestarDuts > 0) {
                        dutsUsuario = dutsUsuario - cantidad;
                        
                        // Para el que envía
                        transacciones(connection, cedulaUsuario, cedula, cantidad, dutsUsuario + cantidad, "resta");
                        
                        // Para el que recibe
                        
                        long saldo_anterior = saldo(connection, cedula);
                        transacciones(connection, cedula, cedulaUsuario, cantidad, saldo_anterior - cantidad, "suma");
                    }
                }
                catch (SQLException e) {
                    System.err.println("Error al descontar duts: " + e.getMessage());
                }
                
                return "Transacción realizada correctamente";
            }
            else {
                return "Algo ha fallado en la transacción";
            }
            
        } catch (SQLException e) {
            System.err.println("Error en la transacción: " + e.getMessage());
        }
        
        return "Ha ocurrido algún error";
    }
    
    public static String recargarDuts(long cantidad){
        
        long saldo_anterior = dutsUsuario;
        
        String query = "UPDATE usuarios SET duts = duts + ? WHERE cedula = ?";
        
        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setLong(1, cantidad);
            statement.setString(2, cedulaUsuario);

            int filasAfectadas = statement.executeUpdate();
            
            if(filasAfectadas > 0) {
                dutsUsuario = dutsUsuario + cantidad;
                transacciones(connection, cedulaUsuario, "null", cantidad, saldo_anterior, "suma");
                return "Transacción realizada correctamente";
            }
            else {
                return "Algo ha fallado en la transacción";
            }
            
        } catch (SQLException e) {
            System.err.println("Error en la transacción: " + e.getMessage());
        }
        
        return "Ha ocurrido algún error";
    }
    
    private static void transacciones(Connection connection, String cedula_usuario_emision, String cedula_usuario_recepcion, long monto, long saldo_anterior, String operacion){
        String queryTransaccion = "INSERT INTO transacciones (cedula_usuario_emision, cedula_usuario_recepcion, monto, saldo_anterior, saldo_nuevo, fecha_transaccion) VALUES (?, ?, ?, ?, ?, now());";;
                
        try (PreparedStatement statementTransaccion = connection.prepareStatement(queryTransaccion)){
            statementTransaccion.setString(1, cedula_usuario_emision);
            
            if(cedula_usuario_recepcion.equals("null")){
                statementTransaccion.setString(2, null);
            }
            else {
                statementTransaccion.setString(2, cedula_usuario_recepcion);
            }
            
            statementTransaccion.setLong(3, monto);
            statementTransaccion.setLong(4, saldo_anterior);

            if(operacion.equals("suma")){
                statementTransaccion.setLong(5, saldo_anterior + monto);
            }
            else {
                statementTransaccion.setLong(5, saldo_anterior - monto);
            }

            statementTransaccion.executeUpdate();
        }
        catch (SQLException e) {
            System.err.println("Error al efectuar la transaccón: " + e.getMessage());
        }
    }
    
    private static long saldo(Connection connection, String cedula){
        String query = "SELECT duts FROM usuarios WHERE cedula = ?";
        
        try (PreparedStatement statement = connection.prepareStatement(query)){
            statement.setString(1, cedula);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getLong("duts");
                }
            }
        }
        catch (SQLException e) {
            System.err.println("Error al consultar el saldo: " + e.getMessage());
        }
        
        return 0;
    }
    
    public static void promedioDuts(String cedula){
        String query = """
            SELECT 
                AVG(CASE WHEN fecha_transaccion >= DATE_SUB(NOW(), INTERVAL 1 WEEK) THEN saldo_nuevo END) AS promedio_semanal,
                AVG(CASE WHEN fecha_transaccion >= DATE_SUB(NOW(), INTERVAL 1 MONTH) THEN saldo_nuevo END) AS promedio_mensual,
                AVG(CASE WHEN fecha_transaccion >= DATE_SUB(NOW(), INTERVAL 6 MONTH) THEN saldo_nuevo END) AS promedio_semestral,
                AVG(CASE WHEN fecha_transaccion >= DATE_SUB(NOW(), INTERVAL 1 YEAR) THEN saldo_nuevo END) AS promedio_anual
            FROM 
                transacciones
            WHERE 
                cedula_usuario_emision = ?;
        """;
        
        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setString(1, cedula);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    promedios[0] = resultSet.getLong("promedio_semanal");
                    promedios[1] = resultSet.getLong("promedio_mensual");
                    promedios[2] = resultSet.getLong("promedio_semestral");
                    promedios[3] = resultSet.getLong("promedio_anual");
                } else {
                    System.out.println("No se encontraron registros para la cédula: " + cedula);
                }
            }
        }catch (SQLException e) {
            System.err.println("Error al efectuar la transaccón: " + e.getMessage());
        }
        
    }
    
    public static String getCedulaUsuario(){
        return cedulaUsuario;
    }
    
    public static String getNombreUsuario(){
        return nombreUsuario;
    }
    
    public static String getCorreoUsuario(){
        return correoUsuario;
    }
    
    public static long getDutsUsuario(){
        return dutsUsuario;
    }
    
    public static long[] getPrometiosUsuario(){
        return promedios;
    }
}
