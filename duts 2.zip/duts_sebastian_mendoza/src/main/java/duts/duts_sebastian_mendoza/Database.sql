CREATE TABLE usuarios (
    cedula VARCHAR(10) NOT NULL,
    nombre VARCHAR(255) NOT NULL,
    correo VARCHAR(255) NOT NULL UNIQUE,
    clave VARCHAR(255) NOT NULL,
    duts BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (cedula)
);

CREATE TABLE transacciones (
    id INT NOT NULL AUTO_INCREMENT,
    cedula_usuario_emision VARCHAR(10) NOT NULL,
    cedula_usuario_recepcion VARCHAR(10) NULL,
    monto BIGINT NOT NULL,
    saldo_anterior BIGINT NOT NULL,
    saldo_nuevo BIGINT NOT NULL,
    fecha_transaccion DATETIME NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (cedula_usuario_emision) REFERENCES usuarios(cedula),
    FOREIGN KEY (cedula_usuario_recepcion) REFERENCES usuarios(cedula)
);

CREATE TABLE eventos (
    id INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(255) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    duts BIGINT NOT NULL,
    PRIMARY KEY (id),
);

CREATE TABLE registro_eventos (
    id INT NOT NULL AUTO_INCREMENT,
    cedula_usuario VARCHAR(10) NOT NULL,
    fecha_registro DATETIME NOT NULL
    FOREIGN KEY (cedula_usuario) REFERENCES usuarios(cedula),
);