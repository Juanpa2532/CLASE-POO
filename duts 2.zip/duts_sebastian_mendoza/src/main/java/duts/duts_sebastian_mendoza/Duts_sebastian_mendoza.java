package duts.duts_sebastian_mendoza;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;

public class Duts_sebastian_mendoza {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
        new Login().setVisible(true);
    });
    }
}
