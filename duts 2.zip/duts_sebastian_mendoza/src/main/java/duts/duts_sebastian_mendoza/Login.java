package duts.duts_sebastian_mendoza;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblUsuario = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblClave = new javax.swing.JLabel();
        txtClave = new javax.swing.JPasswordField();
        sprForm = new javax.swing.JSeparator();
        btnLogin = new javax.swing.JButton();
        lblTituloLogin = new javax.swing.JLabel();
        lblMsgError = new javax.swing.JLabel();
        lblMsgError.setVisible(false);
        lblCopyright = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblRegistrar = new javax.swing.JLabel();
        sprRegister = new javax.swing.JSeparator();
        lblSubtituloLogin1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Iniciar sesión");
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(0, 0, 102));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(480, 200));
        setName("frmLogin"); // NOI18N
        setPreferredSize(new java.awt.Dimension(410, 370));
        setResizable(false);
        getContentPane().setLayout(null);

        lblUsuario.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblUsuario.setLabelFor(txtUsuario);
        lblUsuario.setText("Usuario");
        getContentPane().add(lblUsuario);
        lblUsuario.setBounds(60, 90, 51, 20);
        getContentPane().add(txtUsuario);
        txtUsuario.setBounds(150, 90, 183, 22);

        lblClave.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblClave.setLabelFor(txtClave);
        lblClave.setText("Clave");
        getContentPane().add(lblClave);
        lblClave.setBounds(60, 130, 37, 20);
        getContentPane().add(txtClave);
        txtClave.setBounds(150, 130, 183, 22);
        getContentPane().add(sprForm);
        sprForm.setBounds(60, 160, 273, 10);

        btnLogin.setBackground(new java.awt.Color(0, 102, 102));
        btnLogin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLogin.setForeground(new java.awt.Color(255, 255, 255));
        btnLogin.setText("Iniciar sesión");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });
        getContentPane().add(btnLogin);
        btnLogin.setBounds(60, 180, 270, 27);

        lblTituloLogin.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        lblTituloLogin.setText("PLATAFORMA FINANCIERA");
        getContentPane().add(lblTituloLogin);
        lblTituloLogin.setBounds(60, 14, 271, 23);

        lblMsgError.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        lblMsgError.setForeground(new java.awt.Color(255, 0, 51));
        lblMsgError.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMsgError.setText("¡Usuario o clave incorrectos!");
        lblMsgError.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(lblMsgError);
        lblMsgError.setBounds(60, 260, 270, 28);

        lblCopyright.setFont(new java.awt.Font("Corbel Light", 0, 12)); // NOI18N
        lblCopyright.setText("Copyright Sebastián Mendoza ©");
        getContentPane().add(lblCopyright);
        lblCopyright.setBounds(5, 310, 167, 22);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("ó");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(190, 210, 9, 20);

        lblRegistrar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblRegistrar.setForeground(new java.awt.Color(0, 102, 102));
        lblRegistrar.setText("Registrarse");
        lblRegistrar.setToolTipText("");
        lblRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRegistrarMouseClicked(evt);
            }
        });
        getContentPane().add(lblRegistrar);
        lblRegistrar.setBounds(160, 230, 67, 20);

        sprRegister.setBackground(new java.awt.Color(0, 102, 102));
        sprRegister.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(sprRegister);
        sprRegister.setBounds(160, 250, 67, 5);

        lblSubtituloLogin1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        lblSubtituloLogin1.setText("Dinero Digital UTS");
        getContentPane().add(lblSubtituloLogin1);
        lblSubtituloLogin1.setBounds(130, 43, 122, 28);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        
        String usuario = this.txtUsuario.getText().trim();
        String clave = new String(this.txtClave.getPassword());
        
        boolean login = Database.login(usuario, clave);
            
        if (login) {
            new Home().setVisible(true);
            dispose();
        } else {
            lblMsgError.setVisible(true);
        }    
    }//GEN-LAST:event_btnLoginActionPerformed

    private void lblRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRegistrarMouseClicked
        new Register().setVisible(true);
        dispose();
    }//GEN-LAST:event_lblRegistrarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblClave;
    private javax.swing.JLabel lblCopyright;
    private javax.swing.JLabel lblMsgError;
    private javax.swing.JLabel lblRegistrar;
    private javax.swing.JLabel lblSubtituloLogin1;
    private javax.swing.JLabel lblTituloLogin;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JSeparator sprForm;
    private javax.swing.JSeparator sprRegister;
    private javax.swing.JPasswordField txtClave;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
